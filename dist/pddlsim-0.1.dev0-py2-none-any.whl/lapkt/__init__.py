import sys, os

# add fd parser to path
sys.path.append(os.path.join(os.getcwd(),'lapkt/LAPKT-dev/external'))

