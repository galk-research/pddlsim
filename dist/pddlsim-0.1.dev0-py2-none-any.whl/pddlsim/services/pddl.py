class PDDL():
    def __init__(self, domain_path, problem_path):
        self.domain_path = domain_path
        self.problem_path = problem_path
    
