class PDDL():
    """
    Contains the paths to the domain and problem pddl files used
    """

    def __init__(self, domain_path, problem_path):
        self.domain_path = domain_path
        self.problem_path = problem_path
