class Executor(object):
    """docstring for Executor."""
    def __init__(self):
        super(Executor, self).__init__()

    def initilize(self,simulator):
        return None

    def next_action(self):
        return None
